This sample code supports Calvin College
[CS 336](https://cs.calvin.edu/courses/cs/336/kvlinden)
[Unit 8: React](https://cs.calvin.edu/courses/cs/336/kvlinden/08react/index.html).

These are the starter files for an implementation of the (old) Facebook ReactJS tutorial -
the comment list:

- https://cs.calvin.edu/courses/cs/336/kvlinden/08react/backup/Tutorial_React.html
(formerly at https://facebook.github.io/react/docs/tutorial.html)

The completed lab exercise will serve as the basis for the application built in
the "Application" section of the course.

